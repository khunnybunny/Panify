import { error } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DialogService } from 'src/app/dialog.service';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css'],
  providers: [DialogService]
})

export class DialogComponent implements OnInit {

  dialog: String[]

  constructor(private dialogService: DialogService) { }

  ngOnInit() {
    this.dialog = this.dialogService.findAll()
  }

  onSave(regForm: NgForm) {
    //need to check if udpate or insert the form
    this.dialogService.setDialog(regForm)
    // .subscribe(
    //   data =>
    //     console.log(data),
    //   error =>
    //     console.log(error)
    // )

    this.dialog = this.dialogService.findAll()
  }
}