import { Component, Inject, OnInit, Output } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog, MatDialogConfig, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogService } from '../dialog.service';
import { DialogComponent } from '../header/dialog/dialog.component';

@Component({
  selector: 'app-progress',
  templateUrl: './progress.component.html',
  styleUrls: ['./progress.component.css']
})
export class ProgressComponent implements OnInit {

  constructor(private dialogService: DialogService, public dialog: MatDialog
    // private formBuilder: FormBuilder,
    // private dialogRef: MatDialogRef<DialogComponent>,
    // @Inject(MAT_DIALOG_DATA) private data
  ) { }

  dialogList: String[]

  ngOnInit() {
    this.dialogList = this.dialogService.getDialog()
    this.dialogList = this.dialogService.findAll()
  }

  onEdit(index): void {
    // console.log(index);
    let webstack = localStorage.getItem("token")
    let obj = JSON.parse(webstack)
    const dialogConfig = new MatDialogConfig()
    dialogConfig.disableClose = true
    dialogConfig.autoFocus = true
    this.dialog.open(DialogComponent, dialogConfig)
  }

  onDelete(index: number) {
    // alert(index)
    var result = confirm("Are you sure?")
    if (result) {
      this.dialogService.delete(index)
      this.dialogList = this.dialogService.findAll()
    }

  }
}
