import { Injectable } from '@angular/core';
import { NgForm } from '@angular/forms';


@Injectable({
  providedIn: 'root'
})

export class DialogService {

  constructor() { }

  findAll(): String[] {
    if (localStorage.getItem('token') != null) {
      return JSON.parse(localStorage.getItem('token'))
    }
    return null
  }

  getDialog() {
    const dialogList = JSON.parse(localStorage.getItem("token"))
    return dialogList
  }

  setDialog(regForm: NgForm) {
    const obj = {
      task: regForm.value.task,
      priority: regForm.value.priority,
      progress: regForm.value.progress,
      description: regForm.value.description,
      date: regForm.value.date,
    }
    this.addToken(obj)
  }

  addToken(obj) {
    if (localStorage.getItem('token') == null) {
      let list: String[]
      list.push(obj)
      return localStorage.setItem('token', JSON.stringify(list))
    } else {
      let list: String[] = JSON.parse(localStorage.getItem('token'))
      list.push(obj)
      return localStorage.setItem('token', JSON.stringify(list))
    }
  }

  delete(index: number): void {
    let list: String[] = JSON.parse(localStorage.getItem('token'))
    list.splice(index, 1)
    localStorage.setItem('token', JSON.stringify(list))
  }
}
