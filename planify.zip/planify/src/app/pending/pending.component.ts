import { Component, OnInit, Output } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { DialogService } from '../dialog.service';
import { DialogComponent } from '../header/dialog/dialog.component';

@Component({
  selector: 'app-pending',
  templateUrl: './pending.component.html',
  styleUrls: ['./pending.component.css']
})
export class PendingComponent implements OnInit {

  constructor(private dialogService: DialogService, public dialog: MatDialog) { }

  dialogList = []
  
  ngOnInit() {
    this.dialogList = this.dialogService.getDialog()
  }

  onEdit(index): void {
    // console.log(index);
    let webstack = localStorage.getItem("token")
    let obj = JSON.parse(webstack)
    const dialogConfig = new MatDialogConfig()
    dialogConfig.disableClose = true
    dialogConfig.autoFocus = true
    this.dialog.open(DialogComponent, dialogConfig)
  }

  onDelete(index: number) {
    // alert(index)
    var result = confirm("Are you sure?")
    if (result) {
      this.dialogService.delete(index)
      this.dialogList = this.dialogService.findAll()
    }

  }
}
